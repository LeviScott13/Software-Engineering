package hw1a;

public interface Teleporter {
	
	public abstract String teleport(String dest);
	
}
